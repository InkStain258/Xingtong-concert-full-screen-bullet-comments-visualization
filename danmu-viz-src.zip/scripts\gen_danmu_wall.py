#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成 danmu_wall.json 和 danmu_index.json
- danmu_wall.json: 全量弹幕 [{m: 分钟, t: 文本, e: 情感}, ...]  用于照片墙
- danmu_index.json: {keyword: [danmu wall indices]}  用于词云联动
"""

import json, re, os
from collections import defaultdict

DATA_FILES = [
    "C:/Users/bnustupid/Downloads/p1.txt",
]
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

EMOTION_KEYWORDS = {
    # 应援——角色名、口号（覆盖面最大，优先匹配）
    "应援": ["星瞳","瞳宝","瞳宝宝","瞳姐","小星星","星星","一剑开天门","加油","冲啊",
              "应援","支持","最棒的","周年","星光","周年快乐","生日快乐","纪念",
              "星瞳加油","爱星瞳","我的星瞳","瞳","2568","永不散场","不散场","五周年",
              "越来越好","要火","一定要火","支持你","永远爱你","永远支持"],
    # 爱意——亲昵表达
    "爱意": ["mua","MUA","爱你","好想你","想你","宝宝","妈妈","么么哒","亲亲",
              "抱抱","爱心","爱意","心心","老婆","老公","崽崽","小可爱","爱了爱了",
              "爱你哟","宝贝","好喜欢","好爱","最爱","么么","啵啵","mua~","muamua"],
    # 欢笑——笑声和"乐"相关
    "欢笑": ["哈哈","呵呵","嘿嘿","嘻嘻","吼吼","鹅鹅","好活","笑死","笑","笑了",
              "搞笑","好笑","666","6666","hhh","HHH","bushi","草","绷不住",
              "逆天","难绷","乐","笑死我了","笑嘻了","真绷","蚌埠住了"],
    # 欢呼——激动/惊叹
    "欢呼": ["啊啊","哇","哇哇","太帅","帅帅帅","绝了","牛","牛逼","厉害","高潮",
              "爱了","绝绝子","amazing","芜湖","起飞","最强","这段","这里",
              "太超过了","太好了","赛高","牛批","太强","！！","好强","超强",
              "卧槽","wc","牛逼","骚","燃","炸裂","无敌","神仙"],
    # 感慨——感动/伤感
    "感慨": ["哭","泪","感动","泪目","呜呜","哭了","哭哭","好哭","眼泪","哽咽",
              "难受","心疼","舍不得","结束了","不想结束","好快","时光","回忆",
              "思念","破防了","记得","圆梦","梦回","长大","毕业","再会","永远"],
    # 疑问——好奇/困惑
    "疑问": ["？","?","什么","怎么","为啥","为什么","谁","哪","呢","真的假的",
              "啥","是吗","嘛","干啥","在哪","什么情况","如何","多久","会不会",
              "是这样","不会吧","问一问","问一下","几个人","有人吗"],
    # 玩梗——社区特定梗
    "玩梗": ["b8fq","8fq","加强星瞳","神中神","泰酷辣","破大防","抽象","难绷",
              "差不多得了","典中典","凿凿凿","叽叽叽","急急急","塘","UwU","uwu",
              "uWu","转圈","尤物","姨","唐","绷","典","急","乐","麻","赢",
              "中肯","正确","合理","没毛病","对味","懂你意思","才八点","还真是"],
    # 互动——问候/交流
    "互动": ["晚上好","早上好","下午好","你好","晚安","来了","走了","在吗","看到",
              "人呢","回来了","来了来了","再见","拜拜","打卡","在的","在","欢迎",
              "我来","下班","放学","大家好","各位好","新年好","节日快乐","中午好"],
    # 赞美——褒扬
    "赞美": ["好听","好看","太好看","太好听","好帅","美","漂亮","甜","仙女","天使",
              "宝藏","神仙","太美","绝美","好可爱","萌","乖","迷人的","帅气",
              "酷","优雅","好美","温柔","美丽","超美","绝美","棒","赞",
              "好棒","真棒","很棒","超棒","完美","太酷","好酷"],
    # 调侃——轻度玩笑
    "调侃": ["懒狗","家庭伦理","伦理","母子","开门","开门开门","哭唧唧",
              "窝","嗯哼","哼哼","蒸蒸日上","小心思","确实","实名","是不是要",
              "暗示","明示","别急","别哭","乖宝宝","打破","不会来"],
    # 陪伴——长期/时间相关
    "陪伴": ["一起","陪","等着","蹲","守","等","一直","期待","下次","还来",
              "常驻","还在","还播","一直看","天天","每天","一整年","每年",
              "陪着你","等着你","守候","不离","不弃","永远守护"],
}

EMOTION_EMOJI = {
    "爱意": "💙", "欢呼": "🎉", "欢笑": "😄", "应援": "⚔️", "感慨": "😢",
    "调侃": "🎭", "互动": "👋", "疑问": "❓", "玩梗": "🎯", "赞美": "✨",
    "陪伴": "⏳", "其他": "💬"
}

def classify_emotion(text):
    # 关键词匹配（按优先级）
    for cat, keywords in EMOTION_KEYWORDS.items():
        for kw in keywords:
            if kw in text:
                return cat
    # 模式回退匹配
    if "?" in text or "？" in text:
        return "疑问"
    if "!" in text or "！" in text:
        return "欢呼"
    if text.isdigit() or all(c in "1234567890" for c in text.strip()):
        return "互动"
    chinese_chars = [c for c in text if '\u4e00' <= c <= '\u9fff']
    if len(chinese_chars) <= 2:
        return "互动"
    return "其他"

def main():
    records = []
    base_ts = None
    
    for fpath in DATA_FILES:
        with open(fpath, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                # Format: "line_number→timestamp(ms):content"
                parts = line.split(":", 1)
                if len(parts) != 2:
                    continue
                content = parts[1].strip()
                if not content:
                    continue
                # Extract timestamp from prefix
                ts_match = re.search(r'(\d{13})', parts[0])
                ts = int(ts_match.group(1)) if ts_match else None
                if ts is None:
                    continue
                if base_ts is None or ts < base_ts:
                    base_ts = ts
                records.append({"ts": ts, "text": content})
    
    if not records:
        print("No records found!")
        return
    
    # Convert to relative minutes
    for r in records:
        r["minute"] = int((r["ts"] - base_ts) / 60000)
        r["emotion"] = classify_emotion(r["text"])
    
    # Sort by timestamp
    records.sort(key=lambda x: x["ts"])
    
    total_minutes = records[-1]["minute"]
    print(f"Total danmu: {len(records)}, Duration: ~{total_minutes} minutes")
    
    # Build danmu wall data (compact format)
    wall_data = []
    for r in records:
        wall_data.append({
            "m": r["minute"],
            "t": r["text"],
            "e": r["emotion"]
        })
    
    wall_path = os.path.join(OUTPUT_DIR, "danmu_wall.json")
    with open(wall_path, "w", encoding="utf-8") as f:
        json.dump(wall_data, f, ensure_ascii=False)
    print(f"Generated {wall_path} ({len(wall_data)} entries, {os.path.getsize(wall_path)//1024}KB)")
    
    # Build keyword index (map wordcloud words to danmu indices)
    # Use the wordcloud data from wordcloud_data.json
    wc_path = os.path.join(OUTPUT_DIR, "wordcloud_data.json")
    if os.path.exists(wc_path):
        with open(wc_path, "r", encoding="utf-8") as f:
            wc_data = json.load(f)
    else:
        # Fallback: extract common words
        from collections import Counter
        counter = Counter()
        for r in records:
            for ch in range(len(r["text"]) - 1):
                bigram = r["text"][ch:ch+2]
                if not re.match(r'^[\u4e00-\u9fff\w]{2,}$', bigram):
                    continue
                counter[bigram] += 1
        wc_data = [{"name": w, "value": c} for w, c in counter.most_common(60)]
    
    keyword_index = defaultdict(list)
    for i, r in enumerate(records):
        text = r["text"]
        for item in wc_data:
            kw = item["name"]
            if len(kw) >= 2 and kw.lower() in text.lower():
                keyword_index[kw].append(i)
    
    # Convert defaultdict to regular dict for JSON
    keyword_index = dict(keyword_index)
    
    index_path = os.path.join(OUTPUT_DIR, "danmu_index.json")
    with open(index_path, "w", encoding="utf-8") as f:
        json.dump(keyword_index, f, ensure_ascii=False)
    print(f"Generated {index_path} ({len(keyword_index)} keywords, {os.path.getsize(index_path)//1024}KB)")
    
    # Generate emotion counts per minute for scatter plot
    emotion_categories = list(EMOTION_KEYWORDS.keys()) + ["其他"]
    emotion_by_minute = {m: {e: 0 for e in emotion_categories} for m in range(total_minutes + 1)}
    for r in records:
        emotion_by_minute[r["minute"]][r["emotion"]] += 1
    
    emotion_timeline = {
        "minutes": total_minutes + 1,
        "categories": emotion_categories,
        "data": {str(m): emotion_by_minute[m] for m in range(total_minutes + 1)}
    }
    et_path = os.path.join(OUTPUT_DIR, "emotion_timeline.json")
    with open(et_path, "w", encoding="utf-8") as f:
        json.dump(emotion_timeline, f, ensure_ascii=False)
    print(f"Generated {et_path} ({os.path.getsize(et_path)//1024}KB)")
    
    print("Done!")

if __name__ == "__main__":
    main()
