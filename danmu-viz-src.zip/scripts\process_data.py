#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
星瞳直播弹幕数据处理脚本
处理 p1.txt 和 p2.txt，输出各类 JSON 数据文件到 data/ 目录
"""

import json
import re
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone

# 文件路径配置
DATA_FILES = [
    "C:/Users/bnustupid/Downloads/p1.txt",
    "C:/Users/bnustupid/Downloads/p2.txt",
]
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

# 停用词（中文常见停用词 + 无意义字符）
STOP_WORDS = set([
    "的", "了", "在", "是", "我", "有", "和", "就", "不", "人", "都", "一", "一个",
    "上", "也", "很", "到", "说", "要", "去", "你", "会", "着", "没有", "看", "好",
    "自己", "这", "那", "这个", "那个", "他", "她", "它", "们", "啊", "呢", "吧",
    "嗯", "哦", "哈", "嘻", "哈哈", "哈哈哈", "哦哦", "啊啊", "呀", "哇",
    "对", "嗯嗯", "OK", "ok", "哈哈哈哈", "hhh", "hh", "h",
])

# 情感分类关键词（统一版，11类精细划分）
EMOTION_KEYWORDS = {
    # 应援——角色名、口号（覆盖面最大）
    "应援": ["星瞳","瞳宝","瞳宝宝","瞳姐","小星星","星星","一剑开天门","加油","冲啊",
              "应援","支持","最棒的","周年","星光","周年快乐","生日快乐","纪念",
              "星瞳加油","爱星瞳","我的星瞳","瞳","2568","永不散场","不散场","五周年",
              "越来越好","要火","一定要火","支持你","永远爱你","永远支持"],
    # 爱意——亲昵表达
    "爱意": ["mua","MUA","爱你","好想你","想你","宝宝","妈妈","么么哒","亲亲",
              "抱抱","爱心","爱意","心心","老婆","老公","崽崽","小可爱","爱了爱了",
              "爱你哟","宝贝","好喜欢","好爱","最爱","么么","啵啵","mua~","muamua"],
    # 欢笑——笑声和"乐"相关
    "欢笑": ["哈哈","呵呵","嘿嘿","嘻嘻","吼吼","鹅鹅","好活","笑死","笑","笑了",
              "搞笑","好笑","666","6666","hhh","HHH","bushi","草","绷不住",
              "逆天","难绷","乐","笑死我了","笑嘻了","真绷","蚌埠住了"],
    # 欢呼——激动/惊叹
    "欢呼": ["啊啊","哇","哇哇","太帅","帅帅帅","绝了","牛","牛逼","厉害","高潮",
              "爱了","绝绝子","amazing","芜湖","起飞","最强","这段","这里",
              "太超过了","太好了","赛高","牛批","太强","！！","好强","超强",
              "卧槽","wc","牛逼","骚","燃","炸裂","无敌","神仙"],
    # 感慨——感动/伤感
    "感慨": ["哭","泪","感动","泪目","呜呜","哭了","哭哭","好哭","眼泪","哽咽",
              "难受","心疼","舍不得","结束了","不想结束","好快","时光","回忆",
              "思念","破防了","记得","圆梦","梦回","长大","毕业","再会","永远"],
    # 疑问——好奇/困惑
    "疑问": ["？","?","什么","怎么","为啥","为什么","谁","哪","呢","真的假的",
              "啥","是吗","嘛","干啥","在哪","什么情况","如何","多久","会不会",
              "是这样","不会吧","问一问","问一下","几个人","有人吗"],
    # 玩梗——社区特定梗
    "玩梗": ["b8fq","8fq","加强星瞳","神中神","泰酷辣","破大防","抽象","难绷",
              "差不多得了","典中典","凿凿凿","叽叽叽","急急急","塘","UwU","uwu",
              "uWu","转圈","尤物","姨","唐","绷","典","急","乐","麻","赢",
              "中肯","正确","合理","没毛病","对味","懂你意思","才八点","还真是"],
    # 互动——问候/交流
    "互动": ["晚上好","早上好","下午好","你好","晚安","来了","走了","在吗","看到",
              "人呢","回来了","来了来了","再见","拜拜","打卡","在的","在","欢迎",
              "我来","下班","放学","大家好","各位好","新年好","节日快乐","中午好"],
    # 赞美——褒扬
    "赞美": ["好听","好看","太好看","太好听","好帅","美","漂亮","甜","仙女","天使",
              "宝藏","神仙","太美","绝美","好可爱","萌","乖","迷人的","帅气",
              "酷","优雅","好美","温柔","美丽","超美","绝美","棒","赞",
              "好棒","真棒","很棒","超棒","完美","太酷","好酷"],
    # 调侃——轻度玩笑
    "调侃": ["懒狗","家庭伦理","伦理","母子","开门","开门开门","哭唧唧",
              "窝","嗯哼","哼哼","蒸蒸日上","小心思","确实","实名","是不是要",
              "暗示","明示","别急","别哭","乖宝宝","打破","不会来"],
    # 陪伴——长期/时间相关
    "陪伴": ["一起","陪","等着","蹲","守","等","一直","期待","下次","还来",
              "常驻","还在","还播","一直看","天天","每天","一整年","每年",
              "陪着你","等着你","守候","不离","不弃","永远守护"],
}

def load_danmu_data(filepath: str) -> list[dict]:
    """
    加载弹幕数据文件，返回 [{timestamp_ms, content}, ...] 列表
    格式：timestamp:content（每行）
    """
    records = []
    line_count = 0
    error_count = 0
    
    try:
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                line_count += 1
                
                # 格式：timestamp:content
                colon_idx = line.find(":")
                if colon_idx == -1:
                    error_count += 1
                    continue
                
                ts_str = line[:colon_idx]
                content = line[colon_idx + 1:]
                
                # 验证时间戳
                try:
                    ts = int(ts_str)
                    records.append({
                        "ts": ts,
                        "content": content.strip()
                    })
                except ValueError:
                    error_count += 1
                    continue
    except FileNotFoundError:
        print(f"[ERROR] 文件不存在: {filepath}")
        return []
    
    print(f"  [OK] {filepath}: 加载 {len(records)} 条（{line_count} 行，{error_count} 行解析失败）")
    return records


def classify_emotion(content: str) -> str:
    """
    根据关键词 + 模式对弹幕内容进行情感分类
    返回情感类别字符串
    """
    content_lower = content.lower()
    
    # 按优先级检查各情感类别（关键词匹配）
    for category, keywords in EMOTION_KEYWORDS.items():
        for kw in keywords:
            if kw.lower() in content_lower:
                return category
    
    # 模式回退匹配（捕获关键词未覆盖的弹幕）
    # 纯问句
    if "?" in content or "？" in content:
        return "疑问"
    # 纯感叹
    if "!" in content or "！" in content:
        return "欢呼"
    # 纯数字/计数类
    if content.isdigit() or all(c in "1234567890" for c in content.strip()):
        return "互动"
    # 非常短的弹幕（1-2字中文）→ 互动/陪伴
    chinese_chars = [c for c in content if '\u4e00' <= c <= '\u9fff']
    if len(chinese_chars) <= 2:
        return "互动"
    
    return "其他"


def simple_tokenize(text: str) -> list[str]:
    """
    简单中文分词：基于字符n-gram和常见词组
    不依赖jieba，提取2-4字的词组
    """
    tokens = []
    
    # 先提取特殊词汇（品牌词、梗词）
    special_phrases = [
        "一剑开天门", "家庭伦理", "星瞳", "懒狗出现", "急急急", "开门开门",
        "加强星瞳", "凿凿凿", "叽叽叽", "哭唧唧", "mua", "MUA", "UWU", "uwu",
        "好想你", "好听", "太帅了", "帅帅帅", "爱你哟", "宝宝宝宝",
        "周年快乐", "芜湖起飞", "破防了", "6666", "笑死了",
        "太可爱", "神中神", "爱了爱了", "小心思", "蒸蒸日上",
        "B8FQ", "b8fq", "8fq", "开门", "急急", "妈妈", "宝宝",
        "瞳宝宝", "瞳姐", "小星星", "星光", "哈哈哈哈",
    ]
    
    text_lower = text.lower()
    
    for phrase in special_phrases:
        if phrase.lower() in text_lower:
            tokens.append(phrase)
    
    # 提取纯中文词（2-4字）
    chinese_chars = re.sub(r'[^\u4e00-\u9fff]', ' ', text)
    words = chinese_chars.split()
    for word in words:
        if len(word) >= 2:
            tokens.append(word)
        # 提取2字词
        if len(word) >= 2:
            for i in range(len(word) - 1):
                bigram = word[i:i+2]
                tokens.append(bigram)
    
    # 英文词
    english_words = re.findall(r'[a-zA-Z]{2,}', text)
    tokens.extend(english_words)
    
    return tokens


def build_word_freq(records: list[dict], top_n: int = 100) -> list[dict]:
    """
    统计词频，返回前 top_n 个词
    """
    # 尝试使用jieba，失败则用简单分词
    use_jieba = False
    try:
        import jieba
        use_jieba = True
        print("  [OK] 使用jieba分词")
        # 添加自定义词典
        for phrase in ["一剑开天门", "家庭伦理", "懒狗出现", "加强星瞳", "哭唧唧", "凿凿凿", "叽叽叽"]:
            jieba.add_word(phrase)
    except ImportError:
        print("  [WARN] jieba未安装，使用简单分词")
    
    counter = Counter()
    
    for rec in records:
        content = rec["content"]
        
        if use_jieba:
            words = jieba.cut(content, cut_all=False)
            tokens = list(words)
        else:
            tokens = simple_tokenize(content)
        
        for token in tokens:
            token = token.strip()
            # 过滤停用词和单字（保留有意义的特殊单字除外）
            if len(token) < 2:
                continue
            if token in STOP_WORDS:
                continue
            if re.match(r'^[0-9]+$', token):
                continue
            counter[token] += 1
    
    result = []
    for word, count in counter.most_common(top_n):
        result.append({"name": word, "value": count})
    
    return result


def compute_timeline(records: list[dict], interval_seconds: int = 60) -> dict:
    """
    按时间间隔统计弹幕数量
    返回 {timestamps: [...], counts: [...], minutes: [...]}
    """
    if not records:
        return {"timestamps": [], "counts": [], "minutes": []}
    
    # 找到起止时间
    min_ts = min(r["ts"] for r in records)
    max_ts = max(r["ts"] for r in records)
    
    interval_ms = interval_seconds * 1000
    
    # 按桶分组
    buckets = defaultdict(int)
    for rec in records:
        bucket_idx = (rec["ts"] - min_ts) // interval_ms
        buckets[bucket_idx] += 1
    
    total_buckets = int((max_ts - min_ts) / interval_ms) + 1
    
    timestamps = []
    counts = []
    minutes = []
    
    for i in range(total_buckets):
        ts = min_ts + i * interval_ms
        timestamps.append(ts)
        counts.append(buckets.get(i, 0))
        minutes.append(round(i * interval_seconds / 60, 1))
    
    return {
        "timestamps": timestamps,
        "counts": counts,
        "minutes": minutes,
        "interval_seconds": interval_seconds,
        "start_ts": min_ts,
        "end_ts": max_ts,
    }


def compute_emotion_dist(records: list[dict]) -> list[dict]:
    """
    统计情感分类分布
    """
    counter = Counter()
    for rec in records:
        cat = classify_emotion(rec["content"])
        counter[cat] += 1
    
    result = []
    for cat, count in sorted(counter.items(), key=lambda x: -x[1]):
        result.append({"name": cat, "value": count})
    
    return result


def compute_top_messages(records: list[dict], top_n: int = 30) -> list[dict]:
    """
    统计出现最多的弹幕内容（完整内容）
    """
    counter = Counter()
    for rec in records:
        content = rec["content"].strip()
        # 过滤过短或无意义内容
        if len(content) < 2:
            continue
        counter[content] += 1
    
    result = []
    for content, count in counter.most_common(top_n):
        result.append({"content": content, "count": count})
    
    return result


def compute_heatmap(records: list[dict]) -> dict:
    """
    计算按分钟×情感类别的热力图数据
    """
    if not records:
        return {"data": [], "minutes": [], "categories": []}
    
    min_ts = min(r["ts"] for r in records)
    
    categories = list(EMOTION_KEYWORDS.keys()) + ["其他"]
    
    # 按分钟分组
    bucket_data = defaultdict(lambda: defaultdict(int))
    
    for rec in records:
        minute_idx = (rec["ts"] - min_ts) // (60 * 1000)
        cat = classify_emotion(rec["content"])
        bucket_data[minute_idx][cat] += 1
    
    max_minute = max(bucket_data.keys()) if bucket_data else 0
    
    # 构建 ECharts heatmap 数据格式: [minute_idx, cat_idx, value]
    heatmap_data = []
    for minute_idx in range(max_minute + 1):
        for cat_idx, cat in enumerate(categories):
            val = bucket_data[minute_idx].get(cat, 0)
            if val > 0:
                heatmap_data.append([minute_idx, cat_idx, val])
    
    minutes = [str(i) for i in range(max_minute + 1)]
    
    return {
        "data": heatmap_data,
        "minutes": minutes,
        "categories": categories,
    }


def compute_stats(records: list[dict], timeline: dict) -> dict:
    """
    计算总体统计数据
    """
    if not records:
        return {}
    
    counts = timeline.get("counts", [])
    max_count = max(counts) if counts else 0
    peak_minute = counts.index(max_count) if counts else 0
    
    # 找出峰值时刻附近的典型弹幕
    if records:
        peak_ts_start = timeline["start_ts"] + peak_minute * timeline.get("interval_seconds", 60) * 1000
        peak_ts_end = peak_ts_start + timeline.get("interval_seconds", 60) * 1000
        peak_danmus = [r["content"] for r in records if peak_ts_start <= r["ts"] < peak_ts_end][:5]
    else:
        peak_danmus = []
    
    # 总时长（分钟）
    duration_ms = timeline.get("end_ts", 0) - timeline.get("start_ts", 0)
    duration_min = round(duration_ms / 60000, 1)
    
    return {
        "total_count": len(records),
        "duration_minutes": duration_min,
        "peak_minute": peak_minute,
        "peak_count_per_minute": max_count,
        "avg_count_per_minute": round(len(records) / max(duration_min, 1), 1),
        "peak_danmus": peak_danmus,
        "start_ts": timeline.get("start_ts", 0),
        "end_ts": timeline.get("end_ts", 0),
    }


def compute_radar_data(records: list[dict]) -> dict:
    """
    计算弹幕特征雷达图数据
    维度：互动度、情感强度、梗文化、应援密度、节奏感
    """
    total = len(records) or 1
    
    # 互动度：@、回复、互动词
    interactive_kws = ["开门", "急急急", "叽叽叽", "凿凿凿", "mua", "MUA", "！", "？", "?", "!"]
    interactive = sum(1 for r in records if any(kw in r["content"] for kw in interactive_kws))
    
    # 情感强度：激动词
    intense_kws = ["啊啊", "哇哇", "!!!", "！！！", "AAAA", "aaaa", "太帅", "绝了", "破防"]
    intense = sum(1 for r in records if any(kw in r["content"] for kw in intense_kws))
    
    # 梗文化
    meme_kws = ["家庭伦理", "懒狗出现", "加强星瞳", "哭唧唧", "UWU", "uwu", "b8fq", "神中神", "6666"]
    meme = sum(1 for r in records if any(kw in r["content"] for kw in meme_kws))
    
    # 应援密度
    cheer_kws = ["一剑开天门", "星瞳", "加油", "冲啊", "应援", "周年", "小星星"]
    cheer = sum(1 for r in records if any(kw in r["content"] for kw in cheer_kws))
    
    # 节奏感：短句（<=4字）
    rhythm = sum(1 for r in records if len(r["content"]) <= 4)
    
    # 归一化为0-100分
    def normalize(count: int, max_val: int = None) -> float:
        if max_val is None:
            max_val = total * 0.3  # 30%为满分
        return min(100, round(count / max_val * 100, 1))
    
    return {
        "indicators": [
            {"name": "互动度", "max": 100},
            {"name": "情感强度", "max": 100},
            {"name": "梗文化", "max": 100},
            {"name": "应援密度", "max": 100},
            {"name": "节奏感", "max": 100},
        ],
        "values": [
            normalize(interactive, total * 0.4),
            normalize(intense, total * 0.15),
            normalize(meme, total * 0.1),
            normalize(cheer, total * 0.05),
            normalize(rhythm, total * 0.5),
        ]
    }


def get_sample_danmus(records: list[dict], n: int = 200) -> list[str]:
    """
    随机采样弹幕内容，用于前端弹幕雨动画
    优先选择有代表性的弹幕
    """
    # 过滤：长度在2-15字之间，不含特殊字符
    filtered = [r["content"] for r in records 
                if 2 <= len(r["content"]) <= 15 
                and not re.match(r'^[a-zA-Z0-9\s]+$', r["content"])]
    
    # 去重
    unique = list(set(filtered))
    
    # 如果不够，用全部
    if len(unique) <= n:
        return unique
    
    # 随机采样（用固定seed保证可复现）
    import random
    random.seed(42)
    return random.sample(unique, n)


def main():
    """主函数"""
    print("=" * 60)
    print("星瞳弹幕数据处理脚本")
    print("=" * 60)
    
    # 确保输出目录存在
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print(f"输出目录: {OUTPUT_DIR}")
    
    # Step 1: 加载数据
    print("\n[1/7] 加载弹幕数据...")
    all_records = []
    file_stats = []
    
    for filepath in DATA_FILES:
        records = load_danmu_data(filepath)
        file_stats.append({"file": os.path.basename(filepath), "count": len(records)})
        all_records.extend(records)
    
    print(f"  总计: {len(all_records)} 条弹幕")
    
    # 按时间戳排序
    all_records.sort(key=lambda x: x["ts"])
    
    # Step 2: 计算时间轴
    print("\n[2/7] 计算弹幕时间轴...")
    timeline_1min = compute_timeline(all_records, interval_seconds=60)
    timeline_10s = compute_timeline(all_records, interval_seconds=10)
    print(f"  时间跨度: {timeline_1min['duration_minutes'] if 'duration_minutes' in timeline_1min else '?'} 分钟")
    
    # Step 3: 词频统计
    print("\n[3/7] 统计词频...")
    wordcloud_data = build_word_freq(all_records, top_n=150)
    print(f"  top词: {wordcloud_data[:5]}")
    
    # Step 4: 情感分析
    print("\n[4/7] 情感分析...")
    emotion_data = compute_emotion_dist(all_records)
    print(f"  情感分布: {emotion_data}")
    
    # Step 5: Top弹幕
    print("\n[5/7] 统计Top弹幕...")
    top_messages = compute_top_messages(all_records, top_n=30)
    print(f"  Top弹幕: {top_messages[:5]}")
    
    # Step 6: 热力图
    print("\n[6/7] 计算热力图数据...")
    heatmap_data = compute_heatmap(all_records)
    
    # Step 7: 总体统计
    print("\n[7/7] 计算统计摘要...")
    stats = compute_stats(all_records, timeline_1min)
    stats["file_stats"] = file_stats
    print(f"  总弹幕: {stats['total_count']}")
    print(f"  峰值时刻: 第 {stats['peak_minute']} 分钟，{stats['peak_count_per_minute']} 条/分钟")
    
    # 雷达图数据
    radar_data = compute_radar_data(all_records)
    
    # 弹幕雨样本
    sample_danmus = get_sample_danmus(all_records, n=200)
    
    # 输出JSON文件
    print("\n输出JSON文件...")
    
    def write_json(filename: str, data):
        filepath = os.path.join(OUTPUT_DIR, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        size_kb = os.path.getsize(filepath) / 1024
        print(f"  [OK] {filename} ({size_kb:.1f} KB)")
    
    write_json("danmu_timeline.json", {
        "timeline_1min": timeline_1min,
        "timeline_10s": timeline_10s,
    })
    write_json("wordcloud_data.json", wordcloud_data)
    write_json("emotion_data.json", emotion_data)
    write_json("top_messages.json", top_messages)
    write_json("stats.json", stats)
    write_json("heatmap_data.json", heatmap_data)
    write_json("radar_data.json", radar_data)
    write_json("sample_danmus.json", sample_danmus)
    
    print("\n" + "=" * 60)
    print("数据处理完成！")
    print("=" * 60)
    
    return stats


if __name__ == "__main__":
    stats = main()
    print(f"\n📊 关键指标:")
    print(f"  总弹幕数: {stats.get('total_count', 0):,}")
    print(f"  直播时长: {stats.get('duration_minutes', 0)} 分钟")
    print(f"  峰值时刻: 第 {stats.get('peak_minute', 0)} 分钟")
    print(f"  峰值密度: {stats.get('peak_count_per_minute', 0)} 条/分钟")
    print(f"  平均密度: {stats.get('avg_count_per_minute', 0)} 条/分钟")
